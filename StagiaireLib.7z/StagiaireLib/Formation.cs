﻿namespace StagiaireLib
{
    public enum Formation
    {
        Indetermine,
        CDA,
        DWWM,
        ABCDEV
    }
}
