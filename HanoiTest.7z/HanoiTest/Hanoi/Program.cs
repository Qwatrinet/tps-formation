﻿using ElementsHanoi;

namespace Hanoi
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int taille = 3;
            Jeu jeu = new Jeu(taille);

            jeu.StartGame(taille);

        }
    }
}
