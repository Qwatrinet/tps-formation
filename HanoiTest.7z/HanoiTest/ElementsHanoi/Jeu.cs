﻿namespace ElementsHanoi
{
    public class Jeu
    {

        private List<Tour> tours;

        public List<Tour> Tours { get => tours; }

        /// <summary>
        /// Initialise un jeu de trois tours. La première contient un empilement de blocs de taille size.
        /// </summary>
        /// <param name="taille">taille de la tour de depart</param>
        /// /// <exception cref="ArgumentException">On a entré un paramètre taille négatif ou nul.</exception>
        public Jeu(int taille)
        {
            if (taille <= 0)
            {
                throw new ArgumentException("La taille de la tour de départ doit être positive.");
            }
            tours = new List<Tour>();
            List<Bloc> blocs = new List<Bloc>();
            for (int i = taille; i > 0; i--)
            {
                blocs.Add(new Bloc(i));
            }
            Tour tour1 = new Tour(1, blocs);
            Tour tour2 = new Tour(2, new List<Bloc>());
            Tour tour3 = new Tour(3, new List<Bloc>());
            tours.Add(tour1);
            tours.Add(tour2);
            tours.Add(tour3);
        }
        /// <summary>
        /// Trouve une tour par son numero d'ID
        /// </summary>
        /// <param name="numero">numero de la tour à trouver</param>
        /// <returns>la tour qui a le numero d'entrée</returns>
        /// <exception cref="Exception">Aucune tour n'a le numéro d'entrée.</exception>
        private Tour TourParNumero(int numero)
        {
            Tour? result = this.tours.Find(t => t.Numero == numero);
            if (result == null)
            {
                throw new Exception("Cette tour n'existe pas.");
            }
            return result;
        }

        /// <summary>
        /// Déplacer la tour de Hanoï bloc par bloc suivant les règles.
        /// </summary>
        /// <param name="depart">Tour de départ</param>
        /// <param name="destination">Tour d'arrivée</param>
        /// <param name="tailleTour">Nombre de blocs à déplacer</param>
        /// <exception cref="Exception">On essaie de déplacer une tour sur une autre qui n'existe pas.</exception>
        private void DeplacerTour(Tour depart, Tour destination, int tailleTour)
        {
            if (tailleTour == 1)
            {
                depart.DeplacerBloc(destination);
                return;
            }
            Tour? destinationIntermediaire = this.tours.Find(t => t.Numero != depart.Numero && t.Numero != destination.Numero);
            if (destinationIntermediaire == null)
            {
                throw new Exception("Cette tour n'a pas été trouvée.");
            }
            //On déplace la tour sauf la base dans la position intermédiaire
            DeplacerTour(depart, destinationIntermediaire, tailleTour - 1);

            //On déplace la base
            depart.DeplacerBloc(destination);

            //On déplace la tour intermédiaire sur la destination
            DeplacerTour(destinationIntermediaire, destination, tailleTour - 1);

        }

        /// <summary>
        /// Démarre le jeu
        /// </summary>
        /// <param name="taille">Taille de la tour de départ</param>
        public void StartGame(int taille)
        {
            if (taille <= 0)
            {
                throw new ArgumentOutOfRangeException("la taille doit être positive!");
            }

            DeplacerTour(tours[0], tours[2], taille);
        }



    }
}
