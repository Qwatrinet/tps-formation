﻿namespace ElementsHanoi
{
    public class Tour
    {
        private int numero;
        List<Bloc> blocs;
        /// <summary>
        /// Crée une tour déterminée par son numéro d'identification. Elle contient les blocs listés dans blocs.
        /// </summary>
        /// <param name="numero">l'ID de la tour</param>
        /// <param name="blocs">La liste des blocs contenus dans la tour</param>
        public Tour(int numero, List<Bloc> blocs)
        {
            this.numero = numero;
            this.blocs = blocs;
        }

        public List<Bloc> Blocs { get => blocs; }
        public int Numero { get => numero; }

        /// <summary>
        /// Vérifie qu'on peut déplcaer le dernier bloc de notre tour au dessus d'un autre bloc.
        /// </summary>
        /// <param name="blocDArriveeATester">Le bloc sur lequel on veut empiler le dernier bloc de notre tour.</param>
        /// <returns></returns>
        public bool LegaliteDeplacement(Bloc blocDArriveeATester)
        {
            if (blocDArriveeATester == null)
            {
                return true;
            }
            return this.blocs.Last().Largeur < blocDArriveeATester.Largeur;
        }
        /// <summary>
        /// Déplace le bloc de la tour actuelle à une tour de destination.
        /// </summary>
        /// <param name="destination">La tour de destination.</param>
        /// <exception cref="Exception">On a tenté un mouvement impossible.</exception>
        public void DeplacerBloc(Tour destination)
        {
            if (this.blocs.Count == 0)
            {
                throw new Exception("pas de bloc à déplacer!");
            }
            Bloc blocADeplacer = this.blocs.Last();

            if (destination.blocs.Count > 0)
            {
                if (!LegaliteDeplacement(destination.blocs.Last()))
                {
                    throw new Exception("mouvement illégal");
                }
            }
            Console.WriteLine("Deplacement de la tour " + this.numero + " a la tour " + destination.Numero);
            this.blocs.Remove(blocADeplacer);
            destination.blocs.Add(blocADeplacer);
        }
    }
}
