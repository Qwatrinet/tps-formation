using ElementsHanoi;

namespace TestHanoi
{
    [TestClass]
    public class TestsTour
    {
        [TestMethod]
        public void Tour_DeplacerBloc_DeplacerBlocInexistant_Echec()
        {
            Tour tourdepart = new Tour(1, new List<Bloc>());

            List<Bloc> blocs2 = new List<Bloc>();
            blocs2.Add(new Bloc(1));
            Tour tourarrivee = new Tour(2, blocs2);

            Assert.ThrowsException<Exception>(() => tourdepart.DeplacerBloc(tourarrivee));
        }

        [TestMethod]
        public void Tour_DeplacerBloc_DeplacerBlocGrosSurPetit_Echec()
        {
            List<Bloc> blocs1 = new List<Bloc>();
            blocs1.Add(new Bloc(2));
            Tour tourdepart = new Tour(1, blocs1);
            List<Bloc> blocs2 = new List<Bloc>();
            blocs2.Add(new Bloc(1));
            Tour tourarrivee = new Tour(2, blocs2);

            Assert.ThrowsException<Exception>(() => tourdepart.DeplacerBloc(tourarrivee));
        }

        [TestMethod]
        public void Tour_DeplacerBloc_DeplacerBlocPetitSurGros_Reussite()
        {
            List<Bloc> blocs1 = new List<Bloc>();
            blocs1.Add(new Bloc(1));
            Tour tourdepart = new Tour(1, blocs1);
            List<Bloc> blocs2 = new List<Bloc>();
            blocs2.Add(new Bloc(2));
            Tour tourarrivee = new Tour(2, blocs2);

            tourdepart.DeplacerBloc(tourarrivee);



        }
    }
}